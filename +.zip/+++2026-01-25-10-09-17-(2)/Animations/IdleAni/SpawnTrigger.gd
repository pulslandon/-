extends Area2D

@export var spawner: NodePath

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if not body.is_in_group("player"):
		return

	var s := get_node_or_null(spawner)
	if s and s.has_method("trigger_spawn"):
		s.trigger_spawn()

	queue_free()
