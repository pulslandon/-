extends Node2D
class_name EnemySpawner

@export var enemy_scenes: Array[PackedScene] = []
@export var spawn_points: Array[Node2D] = []   # drag Node2Ds here, or auto-find children
@export var spawn_interval: float = 2.0
@export var max_alive: int = 6
@export var total_to_spawn: int = -1           # -1 = infinite
@export var spawn_radius_jitter: float = 12.0  # small random offset

@export var safe_distance_from_player: float = 180.0
@export var player_group: StringName = &"player"

var _alive: int = 0
var _spawned_total: int = 0
var _t: float = 0.0
var _player: Node2D

func _ready() -> void:
	_player = get_tree().get_first_node_in_group(player_group) as Node2D

	# Optional auto-fill spawn_points from children
	if spawn_points.is_empty():
		for c in get_children():
			if c is Node2D:
				spawn_points.append(c)

func _physics_process(delta: float) -> void:
	if enemy_scenes.is_empty() or spawn_points.is_empty():
		return

	if total_to_spawn != -1 and _spawned_total >= total_to_spawn:
		return

	if _alive >= max_alive:
		return

	_t -= delta
	if _t > 0.0:
		return

	_t = spawn_interval
	_try_spawn_one()

func _try_spawn_one() -> void:
	var pos := _pick_spawn_position()
	if pos == null:
		return

	var scene := enemy_scenes[randi() % enemy_scenes.size()]
	var enemy := scene.instantiate()

	# Add to current scene (or your Enemies container node)
	get_tree().current_scene.add_child(enemy)
	(enemy as Node2D).global_position = pos

	_alive += 1
	_spawned_total += 1

	# If your enemy has a died signal, hook it.
	# Otherwise, connect to tree_exited as a fallback.
	if enemy.has_signal("died"):
		enemy.died.connect(_on_enemy_died)
	else:
		enemy.tree_exited.connect(_on_enemy_removed)

func _on_enemy_died() -> void:
	_alive = max(_alive - 1, 0)

func _on_enemy_removed() -> void:
	_alive = max(_alive - 1, 0)

func _pick_spawn_position(out_pos: Vector2) -> bool:
	for _i in range(12):
		var p := spawn_points[randi() % spawn_points.size()].global_position
		p += Vector2(
			randf_range(-spawn_radius_jitter, spawn_radius_jitter),
			randf_range(-spawn_radius_jitter, spawn_radius_jitter)
		)

		if _player and p.distance_to(_player.global_position) < safe_distance_from_player:
			continue

		out_pos = p
		return true

	return false
