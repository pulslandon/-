extends Node2D
class_name Spawner

@export var enemy_scene: PackedScene
@export var spawn_once: bool = true
@export var respawn_delay: float = 0.0          # 0 = no respawn timer
@export var spawn_parent: NodePath              # optional: where to put the enemy (defaults to current_scene)
@export var weapon_override: WeaponData         # optional: override enemy.weapon on spawn

# --- NEW: spawn when some OTHER enemy dies ---
@export var trigger_enemy_path: NodePath        # drag the enemy node here (if in-scene)
@export var trigger_enemy_group: StringName = &""  # OR put the enemy in a group (e.g. "boss") and set this to "boss"
@export var trigger_only_once: bool = true      # spawn only the first time the trigger enemy dies

var _spawned_enemy: Node = null
var _cooldown: bool = false

var _trigger_bound: bool = false
var _trigger_fired: bool = false

func _ready() -> void:
	_bind_trigger_enemy()

func _bind_trigger_enemy() -> void:
	if _trigger_bound:
		return

	var trigger: Node = null

	# Prefer explicit path if provided
	if trigger_enemy_path != NodePath(""):
		trigger = get_node_or_null(trigger_enemy_path)
	# Otherwise try group lookup
	elif trigger_enemy_group != &"":
		var nodes := get_tree().get_nodes_in_group(String(trigger_enemy_group))
		if nodes.size() > 0:
			trigger = nodes[0] # first match

	if trigger == null:
		return

	_trigger_bound = true

	# If the enemy has a died signal, use it
	if trigger.has_signal("died"):
		trigger.connect("died", Callable(self, "_on_trigger_enemy_died"))
	else:
		# Fallback: when it leaves the tree (queue_free / freed)
		trigger.tree_exited.connect(_on_trigger_enemy_died, CONNECT_ONE_SHOT)

func _on_trigger_enemy_died() -> void:
	if trigger_only_once and _trigger_fired:
		return
	_trigger_fired = true

	# Optional: if you want respawn_delay behavior to still apply, just call spawn_enemy()
	spawn_enemy()

func can_spawn() -> bool:
	if enemy_scene == null:
		return false
	if _cooldown:
		return false
	if spawn_once and _spawned_enemy != null and is_instance_valid(_spawned_enemy):
		return false
	return true

func spawn_enemy() -> Node:
	if not can_spawn():
		return null

	var inst := enemy_scene.instantiate()
	if inst == null:
		return null

	# parent
	var parent: Node = get_tree().current_scene
	if spawn_parent != NodePath(""):
		parent = get_node_or_null(spawn_parent)
		if parent == null:
			parent = get_tree().current_scene

	parent.add_child(inst)

	# position
	if inst is Node2D:
		(inst as Node2D).global_position = global_position

	# optional: set weapon before _ready runs (best-effort)
	if weapon_override != null and ("weapon" in inst):
		inst.weapon = weapon_override

	_spawned_enemy = inst

	# respawn handling (only for this spawned enemy)
	if respawn_delay > 0.0:
		_cooldown = true
		inst.tree_exited.connect(_on_enemy_exited_tree, CONNECT_ONE_SHOT)

	return inst

func _on_enemy_exited_tree() -> void:
	_spawned_enemy = null
	if respawn_delay <= 0.0:
		_cooldown = false
		return

	await get_tree().create_timer(respawn_delay).timeout
	_cooldown = false

func trigger_spawn() -> void:
	spawn_enemy()
