extends Node2D

# -------------------------
# Wave Spawner
# -------------------------

@export var enemy_scene: PackedScene          ## The rival/enemy packed scene
@export var enemies_per_wave: int = 1      ## How many enemies to spawn each wave
@export var enemies_increase_per_wave: int = 0 ## Optionally increase count each wave
@export var spawn_points: Array[NodePath] = [] ## NodePaths to marker positions; falls back to spawner position
@export var spawn_spread: float = 120.0       ## Random X spread when no spawn points assigned
@export var wave_start_delay: float = 1.5     ## Seconds before first wave and between waves

@export_group("Debug")
@export var auto_start: bool = true           ## Start spawning on _ready

var current_wave: int = 0
var alive_count: int = 0
var spawning: bool = false

signal wave_started(wave_number: int)
signal wave_cleared(wave_number: int)
signal all_waves_cleared            ## emitted only if max_waves > 0 and reached

@export var max_waves: int = 0  ## 0 = infinite


func _ready() -> void:
	if auto_start:
		start()


# -------------------------
# Public API
# -------------------------
func start() -> void:
	if spawning:
		return
	spawning = true
	current_wave = 0
	_begin_next_wave()


func stop() -> void:
	spawning = false


# -------------------------
# Wave logic
# -------------------------
func _begin_next_wave() -> void:
	if not spawning:
		return

	current_wave += 1

	if max_waves > 0 and current_wave > max_waves:
		spawning = false
		emit_signal("all_waves_cleared")
		print("[WaveSpawner] All waves complete!")
		return

	print("[WaveSpawner] Wave %d starting in %.1fs..." % [current_wave, wave_start_delay])
	await get_tree().create_timer(wave_start_delay).timeout

	if not spawning:
		return

	_spawn_wave()


func _spawn_wave() -> void:
	var count := enemies_per_wave + (enemies_increase_per_wave * (current_wave - 1))
	count = max(1, count)
	alive_count = count

	emit_signal("wave_started", current_wave)
	print("[WaveSpawner] Wave %d — spawning %d enemies" % [current_wave, count])

	for i in count:
		_spawn_enemy()


func _spawn_enemy() -> void:
	if enemy_scene == null:
		push_error("[WaveSpawner] enemy_scene is not assigned!")
		return

	var enemy: Node2D = enemy_scene.instantiate()

	# Pick spawn position
	var spawn_pos := _pick_spawn_position()

	# Add to scene first so global_position works
	get_parent().add_child(enemy)
	enemy.global_position = spawn_pos

	# Track death by listening to tree_exiting (fires right before queue_free removes the node)
	enemy.tree_exiting.connect(_on_enemy_died)


func _pick_spawn_position() -> Vector2:
	if spawn_points.size() > 0:
		# Cycle through spawn points in order (wraps around)
		var idx := (alive_count - 1) % spawn_points.size()   # alive_count still full here
		var point_path := spawn_points[idx]
		var point := get_node_or_null(point_path)
		if point is Node2D:
			return (point as Node2D).global_position

	# Fallback: random spread around spawner
	var offset := randf_range(-spawn_spread * 0.5, spawn_spread * 0.5)
	return global_position + Vector2(offset, 0.0)


# -------------------------
# Enemy tracking
# -------------------------
func _on_enemy_died() -> void:
	alive_count -= 1
	print("[WaveSpawner] Enemy died. Remaining: %d" % alive_count)

	if alive_count <= 0:
		emit_signal("wave_cleared", current_wave)
		print("[WaveSpawner] Wave %d cleared!" % current_wave)
		_begin_next_wave()
