extends Control

@export var game_scene: PackedScene

var can_start := true

func _ready():
	grab_focus() # ensures input works immediately

func _unhandled_input(event):
	if not can_start:
		return

	if event.is_action_pressed("ui_accept"):
		start_game()

func start_game():
	can_start = false
	get_tree().change_scene_to_packed(game_scene)
