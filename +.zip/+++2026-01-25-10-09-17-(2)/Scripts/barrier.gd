extends CollisionShape2D

@export var damage: int = 1000

func _ready():
	connect("body_entered", _on_body_entered)
	queue_free()

func _on_body_entered(body: Node):
	if body.has_method("take_damage"):
		body.take_damage(damage)
