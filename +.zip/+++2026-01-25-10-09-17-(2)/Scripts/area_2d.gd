extends Area2D
class_name Hitbox

@export var lifetime: float = 0.12
@onready var col: CollisionShape2D = $CollisionShape2D

var spawner: Node = null

# Payload (set by whoever spawns the hitbox)
var damage: int = 10
var stance_damage: int = 0
var knockback: Vector2 = Vector2.ZERO
var momentum_multiplier: float = 1.0

# Hit effects
var hit_vfx_scene: PackedScene = null
var hit_sfx: AudioStream = null
var hit_offset: Vector2 = Vector2.ZERO
var spawned_hit_effect: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	await get_tree().create_timer(lifetime).timeout
	queue_free()

# NOTE: added hit_off parameter
func configure(
	vfx: PackedScene,
	sfx: AudioStream,
	hit_off: Vector2,
	shape: Shape2D,
	dmg: int,
	stance_dmg: int,
	kb: Vector2,
	life: float = -1.0
) -> void:
	hit_vfx_scene = vfx
	hit_sfx = sfx
	hit_offset = hit_off

	damage = dmg
	stance_damage = stance_dmg
	knockback = kb

	if life > 0.0:
		lifetime = life
	if col and shape:
		col.shape = shape

func _on_body_entered(body: Node) -> void:
	print("Damage:", damage)
	_spawn_hit_effect_once(body)
	if body == spawner:
		return

	var attacker_pos: Vector2 = global_position
	if spawner is Node2D:
		attacker_pos = (spawner as Node2D).global_position

	var did_hit := false

	# Health damage
	if damage > 0 and body.has_method("take_damage"):
		body.take_damage(damage, attacker_pos)
		did_hit = true

	# Stance damage
	if stance_damage > 0 and body.has_method("take_stance_damage"):
		body.take_stance_damage(stance_damage, attacker_pos)
		did_hit = true

	# Knockback
	if knockback != Vector2.ZERO and body.has_method("apply_knockback"):
		body.apply_knockback(knockback, attacker_pos)

	# ✅ spawn effects once, only if we actually did something
	if did_hit:
		_spawn_hit_effect_once(body)

func _spawn_hit_effect_once(_target: Node) -> void:
	if spawned_hit_effect:
		return
	spawned_hit_effect = true

	if hit_vfx_scene == null and hit_sfx == null:
		return

	var p := global_position + hit_offset

	# VFX
	if hit_vfx_scene != null:
		var fx := hit_vfx_scene.instantiate()
		get_tree().current_scene.add_child(fx)
		if fx is Node2D:
			(fx as Node2D).global_position = p

	# SFX
	if hit_sfx != null:
		var ap := AudioStreamPlayer2D.new()
		get_tree().current_scene.add_child(ap)
		ap.global_position = p
		ap.stream = hit_sfx
		ap.finished.connect(ap.queue_free)
		ap.play()
