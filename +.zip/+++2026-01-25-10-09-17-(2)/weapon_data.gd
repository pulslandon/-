extends Resource
class_name WeaponData

@export var id: String = "unarmed"

# -------------------------------------------------
# CORE (used by player)
# -------------------------------------------------
@export var hitbox_scene: PackedScene

# NEW: arrays (index 0 = step 1). Length = number of attacks.
@export var attack_anims: Array[StringName] = []
@export var hitbox_offsets_array: Array[Vector2] = []
@export var hitbox_delays_array: Array[float] = []
@export var lunge_speeds: Array[float] = []
@export var lunge_durations: Array[float] = []

@export var damages: Array[int] = []
@export var stance_damages: Array[int] = []
@export var knockbacks: Array[Vector2] = []
@export var hitbox_shapes: Array[Shape2D] = []   # RectangleShape2D/CapsuleShape2D/etc
@export var hitbox_lifetimes: Array[float] = []

@export var attack_sfx: AudioStream             # played when a light/air attack starts
@export var heavy_attack_sfx: AudioStream       # played when a heavy attack starts

@export var hit_vfx_scene: PackedScene          # particles / slash / spark scene
@export var hit_sfx: AudioStream                # optional
@export var hit_camera_shake: float = 0.0       # optional
@export var hit_freeze_frames: int = 0          # optional "hitstop"
@export var hit_offset: Vector2 = Vector2.ZERO  # optional small tweak

# -------------------------------------------------
# LEGACY (kept so old weapons still work)
# -------------------------------------------------
@export var hitbox_offsets: Dictionary = { 1: Vector2(30, -75), 2: Vector2(-10, -75) }
@export var hitbox_delays: Dictionary = { 1: 0.17, 2: 0.06 }

@export var lunge: Dictionary = {
	1: {"speed": 420.0, "duration": 0.57},
	2: {"speed": 650.0, "duration": 0.52},
}

@export var anim_attack_1: StringName = &"attack_1"
@export var anim_attack_2: StringName = &"attack_2"
@export var anim_attack_3: StringName = &"attack_3"
@export var anim_attack_4: StringName = &"attack_4"
@export var anim_attack_5: StringName = &"attack_5"

# -------------------------------------------------
# OPTIONAL: Heavy attack (weapon-driven)
# -------------------------------------------------
@export var has_heavy: bool = false
@export var heavy_anim: StringName = &"heavy_attack"
@export var heavy_hitbox_scene: PackedScene = null
@export var heavy_hitbox_delay: float = 0.12
@export var heavy_hitbox_offset: Vector2 = Vector2(95, -75)
@export var heavy_lunge_speed: float = 750.0
@export var heavy_lunge_duration: float = 0.30
@export var heavy_hitbox_shape: Shape2D = null
@export var heavy_damage: int = 0
@export var heavy_stance_damage: int = 0
@export var heavy_knockback: Vector2 = Vector2.ZERO
@export var heavy_hitbox_lifetime: float = 0.12


# -------------------------
# Helpers
# -------------------------

func _idx(step: int) -> int: return step - 1

func get_damage(step: int) -> int:
	var i := _idx(step)
	return damages[i] if i >= 0 and i < damages.size() else 0

func get_stance_damage(step: int) -> int:
	var i := _idx(step)
	return stance_damages[i] if i >= 0 and i < stance_damages.size() else 0

func get_knockback(step: int) -> Vector2:
	var i := _idx(step)
	return knockbacks[i] if i >= 0 and i < knockbacks.size() else Vector2.ZERO

func get_hitbox_shape(step: int) -> Shape2D:
	var i := _idx(step)
	return hitbox_shapes[i] if i >= 0 and i < hitbox_shapes.size() else null

func get_hitbox_lifetime(step: int) -> float:
	var i := _idx(step)
	return hitbox_lifetimes[i] if i >= 0 and i < hitbox_lifetimes.size() else 0.12

func _is_nonempty_anim(a: StringName) -> bool:
	return String(a) != ""

func _legacy_anim_for_step(step: int) -> StringName:
	match step:
		1: return anim_attack_1
		2: return anim_attack_2
		3: return anim_attack_3
		4: return anim_attack_4
		5: return anim_attack_5
	return &""

func _legacy_has_step(step: int) -> bool:
	# A step counts only if there is *actual data* for it — not just the default anim name.
	# The default anim names (attack_1 … attack_5) are all non-empty, which previously
	# caused _legacy_max_step() to always return 5 even for 1-hit weapons, filling
	# steps 2-5 with zero lunge data and breaking the "attack slow" on combo hits 2+.
	if hitbox_offsets.has(step):
		return true
	if hitbox_delays.has(step):
		return true
	if lunge.has(step):
		return true
	# Only count a custom anim name — not the generic "attack_N" default.
	var anim := _legacy_anim_for_step(step)
	var default_anim := StringName("attack_%d" % step)
	if _is_nonempty_anim(anim) and anim != default_anim:
		return true
	return false

func _legacy_max_step() -> int:
	var last := 0
	for step in range(1, 6):
		if _legacy_has_step(step):
			last = step
	return max(last, 1)


func _ensure_arrays_from_legacy() -> void:
	# If the new arrays already exist (authored weapon), do NOT overwrite/pad them.
	# We only auto-fill if the weapon has no authored attack list.
	if attack_anims.size() > 0:
		return

	var max_step := _legacy_max_step() # 1..5 but NOT forced to 5

	# Build arrays exactly to max_step
	attack_anims.resize(max_step)
	hitbox_offsets_array.resize(max_step)
	hitbox_delays_array.resize(max_step)
	lunge_speeds.resize(max_step)
	lunge_durations.resize(max_step)

	for step in range(1, max_step + 1):
		var idx := step - 1

		# --- anims ---
		var anim := _legacy_anim_for_step(step)
		if not _is_nonempty_anim(anim):
			anim = StringName("attack_%d" % step)
		attack_anims[idx] = anim

		# --- offsets ---
		if hitbox_offsets.has(step):
			hitbox_offsets_array[idx] = hitbox_offsets[step]
		else:
			hitbox_offsets_array[idx] = Vector2.ZERO

		# --- delays ---
		if hitbox_delays.has(step):
			hitbox_delays_array[idx] = float(hitbox_delays[step])
		else:
			hitbox_delays_array[idx] = 0.0

		# --- lunge ---
		if lunge.has(step) and lunge[step] is Dictionary:
			var entry: Dictionary = lunge[step]
			lunge_speeds[idx] = float(entry.get("speed", 0.0))
			lunge_durations[idx] = float(entry.get("duration", 0.0))
		else:
			lunge_speeds[idx] = 0.0
			lunge_durations[idx] = 0.0


func _max_hits_from_arrays() -> int:
	# Count only steps that are actually usable (anim not empty).
	# Also ensure we don't exceed available offset/delay entries if those are shorter.
	var a := attack_anims.size()
	if a <= 0:
		return 0

	var b := hitbox_offsets_array.size()
	var c := hitbox_delays_array.size()
	var d := lunge_speeds.size()
	var e := lunge_durations.size()

	# We allow offsets/delays/lunge arrays to be shorter; missing entries default to 0.
	# So max hits is primarily based on attack_anims entries that are non-empty.
	var hits := 0
	for i in range(a):
		if String(attack_anims[i]) == "":
			break
		hits += 1

	return max(hits, 1)


# -------------------------
# API used by Player
# -------------------------
func get_max_combo_hits() -> int:
	_ensure_arrays_from_legacy()
	return _max_hits_from_arrays()

func get_attack_anim(step: int) -> StringName:
	_ensure_arrays_from_legacy()
	var idx := step - 1
	if idx < 0:
		return attack_anims[0] if attack_anims.size() > 0 else &"attack_1"
	if idx >= attack_anims.size():
		return &""  # IMPORTANT: tells player "this step doesn't exist"
	return attack_anims[idx]

func get_hitbox_offset(step: int) -> Vector2:
	_ensure_arrays_from_legacy()
	var idx := step - 1
	if idx >= 0 and idx < hitbox_offsets_array.size():
		return hitbox_offsets_array[idx]
	return Vector2.ZERO

func get_hitbox_delay(step: int) -> float:
	_ensure_arrays_from_legacy()
	var idx := step - 1
	if idx >= 0 and idx < hitbox_delays_array.size():
		return hitbox_delays_array[idx]
	return 0.0

func get_lunge_speed(step: int) -> float:
	_ensure_arrays_from_legacy()
	var idx := step - 1
	if idx >= 0 and idx < lunge_speeds.size():
		return lunge_speeds[idx]
	return 0.0

func get_lunge_duration(step: int) -> float:
	_ensure_arrays_from_legacy()
	var idx := step - 1
	if idx >= 0 and idx < lunge_durations.size():
		return lunge_durations[idx]
	return 0.0
