extends CharacterBody2D


@export var hitbox_scene: PackedScene
@onready var audio_stream_player: AudioStreamPlayer = $AudioStreamPlayer
@onready var hitbox_origin: Node2D = $HitboxOrigin


@export var combo_buffer_time: float = 1.25
var queued_light: bool = false
var buffer_timer: float = 0.8
var current_air_anim: String = ""

var attack_facing_dir: int = 1         
var attack_facing_locked: bool = false

# -------------------------
# SFX (assign in Inspector)
# -------------------------
@export var sfx_damage: AudioStream
@export var sfx_die: AudioStream
@export var sfx_dash: AudioStream
@export var sfx_heavy_attack: AudioStream
@export var sfx_perfect_block: AudioStream
@export var sfx_land: AudioStream
@export var sfx_block: AudioStream


# Optional: lets the death sound play a tiny bit before reloading
@export var die_reload_delay: float = 0.15

func play_sfx(stream: AudioStream) -> void:
	if stream == null:
		return
	# If you want overlapping sounds, set AudioStreamPlayer "Polyphony" > 1 in the Inspector.
	audio_stream_player.stream = stream
	audio_stream_player.play()

# Movement
@export var move_speed: float = 678.0
@export var jump_force: float = 1250.0
@export var gravity: float = 2900.0
@export var max_step_height: float = 10.0
@export var step_checks: int = 5
@export var step_only_when_on_floor := true
@export var wall_slide_speed: float = 260.0      # max fall speed while sliding
@export var wall_slide_only_when_pressing: bool = true


# Dash
@export var dash_speed: float = 1850.0
@export var dash_duration: float = 0.13
@export var dash_cooldown: float = 0.20
var is_dashing: bool = false
var dash_timer: float = 0.0
var cooldown_timer: float = 0.0
var last_direction: int = 1

# Combat / Health
var health: int = 100
var facing_right: bool = true
var is_attacking: bool = false
@export var block_move_multiplier: float = 0.5
@export var block_front_tolerance_px: float = 6.0

enum PlayerState { IDLE, RUN, JUMP, FALL, DASH, ATTACK, BLOCK, STUN }
var state: PlayerState = PlayerState.IDLE

@export var perfect_flash_time: float = 1.08
@export var perfect_flash_color: Color = Color(1, 1, 1, 1)
var _flash_timer: float = 0.0
var _flash_active: bool = false
var _base_modulate: Color

# Heavy attack
@export var heavy_hitbox_delay: float = 0.12
@export var heavy_offset: Vector2 = Vector2(95, -75)
@export var heavy_lunge_speed: float = 750.0
@export var heavy_lunge_duration: float = 0.30
var is_heavy_attacking: bool = false
var was_on_floor: bool = false
@export var weapons: Array[WeaponData] = []
var weapon_index: int = 0
var current_weapon: WeaponData

# Blocking
var Blocking: bool = false
var block_frames: int = 0
const BLOCK_DURATION_FRAMES := 10
const PERFECT_BLOCK_FRAMES := 6
@export var block_damage_multiplier := 0.5

# Stun
var stunned: bool = false
var stun_timer: float = 0.0
@export var stun_duration: float = 0.25

var combo_step: int = 0
@export var combo_timeout: float = 1.5
var combo_timer: float = 1.5
var air_attack_used := false

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

@export var attack_lunge_data := {
	1: { "speed": 420.0, "duration": 0.57 },
	2: { "speed": 650.0, "duration": 0.52 }
}

var attack_lunge_timer := 0.0
var attack_lunge_speed := 0.0
@export var debug_attacks: bool = true
@export var debug_print_sprite_anims: bool = false





func _dbg(msg: String) -> void:
	if debug_attacks:
		print("[ATTACK DBG] ", msg)

func _ready():
	_dbg("SpriteFrames resource path: %s" % (sprite.sprite_frames.resource_path))
	_base_modulate = sprite.modulate

	
	if not sprite.animation_finished.is_connected(_on_animated_sprite_2d_animation_finished):
		sprite.animation_finished.connect(_on_animated_sprite_2d_animation_finished)


	if weapons.size() > 0:
		equip_weapon(0)
		

func _physics_process(delta):
	if stunned:
		stun_timer -= delta
		velocity.x = 0
		
		
	
		if not is_on_floor():
			velocity.y += gravity * delta
		
		apply_wall_slide(delta)
		
		move_with_step(delta)

		if stun_timer <= 0.0:
			stunned = false
		return
		
		if is_on_floor():
			air_attack_used = false

	if not is_on_floor():
		velocity.y += gravity * delta
		
	apply_wall_slide(delta)

	if combo_timer > 0:
		combo_timer -= delta
	else:
		combo_step = 0

	if is_attacking and attack_lunge_timer > 0:
		attack_lunge_timer -= delta
		velocity.x = last_direction * attack_lunge_speed

	var input_direction = Input.get_action_strength("Right") - Input.get_action_strength("Left")

	if input_direction != 0:
		last_direction = sign(input_direction)
		facing_right = last_direction == 1
		sprite.flip_h = not facing_right

	if _flash_active:
		_flash_timer -= delta
		if _flash_timer <= 0.0:
			_flash_active = false
			sprite.modulate = _base_modulate
	
	if Input.is_action_just_pressed("NextWeapon"):
		if !is_attacking and !is_dashing and !stunned:
			equip_weapon(weapon_index + 1)

	if Input.is_action_just_pressed("PrevWeapon"):
		if !is_attacking and !is_dashing and !stunned:
			equip_weapon(weapon_index - 1)


	if Input.is_action_just_pressed("Dash") and not is_dashing and cooldown_timer <= 0:
		start_dash()

	if is_dashing:
		dash_timer -= delta
		velocity.x = last_direction * dash_speed
		if dash_timer <= 0:
			end_dash()
	else:
		if !is_attacking or attack_lunge_timer <= 0:
			var speed_mult := (block_move_multiplier if Blocking else 1.0)
			velocity.x = input_direction * move_speed * speed_mult
		cooldown_timer -= delta

	if Input.is_action_just_pressed("Up") and is_on_floor():
		velocity.y = -jump_force

	Blocking = Input.is_action_pressed("Block")

	if Input.is_action_just_pressed("Block") and !is_attacking:
		Blocking = true
		block_frames = 0

	if Input.is_action_just_pressed("Block"):
		block_frames = 0

	if Blocking:
		block_frames += 1


	move_with_step(delta)
	
	var now_on_floor := is_on_floor()

	if now_on_floor and not was_on_floor:
		play_sfx(sfx_land)

	was_on_floor = now_on_floor
	
	if is_on_floor():
		air_attack_used = false
	
	update_state(input_direction)
	update_animation()
	
	if queued_light and is_attacking:
		buffer_timer -= delta
		if buffer_timer <= 0.0:
			queued_light = false
			buffer_timer = 0.0
		
func trigger_perfect_flash():
	_flash_active = true
	_flash_timer = perfect_flash_time
	sprite.modulate = perfect_flash_color
	
func _get_attack_dir() -> int:
	# If we locked facing for this attack, use it.
	# Otherwise use current facing.
	if attack_facing_locked:
		return attack_facing_dir
	return 1 if facing_right else -1

func _apply_dir_to_offset(offset: Vector2, dir: int) -> Vector2:
	# Flip X only, keep Y unchanged
	return Vector2(offset.x * dir, offset.y)

func _get_attack_spawn_position(offset: Vector2) -> Vector2:
	# Centralized “where should this hitbox appear?”
	var dir := _get_attack_dir()
	_dbg("SPAWN: facing_right=%s last_dir=%d locked=%s attack_dir=%d offset=%s"
	% [str(facing_right), last_direction, str(attack_facing_locked), attack_facing_dir, str(offset)])
	return global_position + _apply_dir_to_offset(offset, dir)
	
func _lock_attack_facing() -> void:
	# Lock the direction the instant an attack starts.
	# Prefer last_direction if it's valid, otherwise use facing_right.
	attack_facing_dir = (last_direction if last_direction != 0 else (1 if facing_right else -1))
	attack_facing_locked = true

func _unlock_attack_facing() -> void:
	attack_facing_locked = false
	attack_facing_dir = 1	


func equip_weapon(index: int) -> void:
	if weapons.is_empty():
		current_weapon = null
		hitbox_scene = null
		return

	var i := wrapi(index, 0, weapons.size())
	var tries := 0
	while tries < weapons.size() and weapons[i] == null:
		i = wrapi(i + 1, 0, weapons.size())
		tries += 1

	if weapons[i] == null:
		push_warning("All weapon slots are null.")
		current_weapon = null
		hitbox_scene = null
		return

	weapon_index = i
	current_weapon = weapons[weapon_index]
	hitbox_scene = current_weapon.hitbox_scene if current_weapon.hitbox_scene != null else null

func move_with_step(delta: float) -> void:
	if step_only_when_on_floor and !is_on_floor():
		move_and_slide()
		return

	if is_dashing or is_attacking:
		move_and_slide()
		return

	var want_step: bool = absf(velocity.x) > 0.01
	var was_on_floor: bool = is_on_floor()
	var old_pos: Vector2 = global_position

	move_and_slide()

	if !want_step:
		return

	var intended_x: float = absf(velocity.x * delta)
	var actual_x: float = absf(global_position.x - old_pos.x)

	if intended_x <= 0.001 or actual_x >= intended_x * 0.2:
		return

	if step_only_when_on_floor and !was_on_floor:
		return

	global_position = old_pos

	var checks: int = max(step_checks, 1)
	var step_height: float = max_step_height / float(checks)

	for i in range(checks):
		var up: float = step_height * float(i + 1)
		global_position = old_pos + Vector2(0.0, -up)
		move_and_slide()
		actual_x = absf(global_position.x - old_pos.x)
		if actual_x >= intended_x * 0.2:
			return

	global_position = old_pos
	move_and_slide()

@warning_ignore("unused_parameter")
func update_state(input_direction: float) -> void:
	if stunned:
		state = PlayerState.STUN
		return
	if is_dashing:
		state = PlayerState.DASH
		return
	if is_attacking:
		state = PlayerState.ATTACK
		return
	if Blocking:
		state = PlayerState.BLOCK
		return

	if not is_on_floor():
		if velocity.y < 0.0:
			state = PlayerState.JUMP
		else:
			state = PlayerState.FALL
		return

	if absf(input_direction) > 0.01:
		state = PlayerState.RUN
	else:
		state = PlayerState.IDLE

func play_anim(name: String) -> void:
	if sprite.animation != name:
		sprite.play(name)

const MAX_COMBO_HITS := 5

func _is_on_wall_only() -> bool:
	return is_on_wall() and not is_on_floor()

func _wall_side_dir() -> int:
	# Returns -1 if wall is on right (normal points left), +1 if wall is on left (normal points right)
	var n := get_wall_normal()
	if n == Vector2.ZERO:
		return 0
	return int(sign(n.x))
	
func apply_wall_slide(delta: float) -> void:
	if not _is_on_wall_only():
		return
	if velocity.y <= 0.0:
		return
	if is_dashing or stunned or is_attacking or Blocking:
		return

	if wall_slide_only_when_pressing:
		var input_dir := Input.get_action_strength("Right") - Input.get_action_strength("Left")
		var wdir := _wall_side_dir() # +1 wall on left, -1 wall on right
		var pressing_into := (input_dir != 0.0 and int(sign(input_dir)) == wdir)
		if not pressing_into:
			return

	velocity.y = min(velocity.y, wall_slide_speed)

func _weapon_max_combo_hits() -> int:
	if current_weapon == null:
		return 2
	var m := current_weapon.get_max_combo_hits()
	_dbg("WEAPON MAX=%d | anims=%d offsets=%d delays=%d" % [
		m,
		current_weapon.attack_anims.size(),
		current_weapon.hitbox_offsets_array.size(),
		current_weapon.hitbox_delays_array.size()
	])
	return m


func _get_weapon_anim_for_step(step: int) -> String:
	var fallback := "attack_%d" % step
	var desired := fallback
	
	if current_weapon != null and current_weapon.has_method("get_max_combo_hits"):
		var max_hits := current_weapon.get_max_combo_hits()
		if step > max_hits:
			return ""  # no such attack for this weapon

	_dbg("Get anim for step=%d (fallback=%s)" % [step, fallback])

	if current_weapon == null:
		_dbg("current_weapon is NULL -> using fallback")
	else:
		_dbg("current_weapon=%s has get_attack_anim=%s" % [
			current_weapon.id,
			str(current_weapon.has_method("get_attack_anim"))
		])

		if current_weapon.has_method("get_attack_anim"):
			var raw = current_weapon.get_attack_anim(step)
			_dbg("weapon.get_attack_anim(%d) -> %s" % [step, str(raw)])
			_dbg("weapon.get_attack_anim(%d) returned: %s (type=%s)" % [
				step, str(raw), typeof(raw)
			])
			desired = String(raw)
	
	if desired == "":
		_dbg("desired was EMPTY -> fallback to %s" % fallback)
		desired = fallback

	if sprite.sprite_frames == null:
		return desired

	var has_desired := sprite.sprite_frames.has_animation(desired)
	var has_fallback := sprite.sprite_frames.has_animation(fallback)
	_dbg("SpriteFrames has desired=%s? %s | has fallback=%s? %s" % [
		desired, str(has_desired), fallback, str(has_fallback)
	])

	if not has_desired:
		if has_fallback:
			_dbg("Desired missing, fallback exists -> returning %s" % fallback)
			return fallback

		if sprite.sprite_frames.has_animation("attack_1"):
			_dbg("Desired+fallback missing -> using attack_1")
			return "attack_1"

		_dbg("No valid attack anim found at all -> returning empty string")
		return ""

	_dbg("Using desired anim: %s" % desired)
	return desired
	


func _is_attack_from_front(attacker_pos: Vector2) -> bool:
	var origin_x := hitbox_origin.global_position.x if hitbox_origin else global_position.x
	var dx := attacker_pos.x - origin_x
	if absf(dx) <= block_front_tolerance_px:
		return true
	return dx > 0.0 if facing_right else dx < 0.0
		


func update_animation() -> void:
	# If we're NOT attacking, play locomotion animations
	if not is_attacking:
		match state:
			PlayerState.IDLE:  play_anim("idle")
			PlayerState.RUN:   play_anim("run")
			PlayerState.JUMP:  play_anim("jump")
			PlayerState.FALL:  play_anim("fall")
			PlayerState.DASH:  play_anim("dash")
			PlayerState.BLOCK: play_anim("block")
			PlayerState.STUN:  play_anim("hit")
			PlayerState.ATTACK:
				pass

	# --- Light attack input (buffered) ---
	if Input.is_action_just_pressed("Attack") and not stunned and not Blocking:
		if not is_on_floor():
			# Air attack: one per airtime, no combo buffering
			if not is_attacking and not air_attack_used:
				start_light_attack(true)
		else:
			# Ground attack: your existing combo buffering
			if is_attacking:
				if not queued_light:
					_dbg("Queued next light hit (current step=%d)" % combo_step)
				queued_light = true
				buffer_timer = combo_buffer_time
			else:
				start_light_attack(false)

	# --- Heavy attack input ---
	if Input.is_action_just_pressed("Heavy") and not is_attacking and not stunned and not Blocking:
		start_heavy_attack()
		
		
func spawn_weapon_heavy_hitbox() -> void:
	if current_weapon == null:
		return

	var scene := current_weapon.heavy_hitbox_scene if current_weapon.heavy_hitbox_scene != null else current_weapon.hitbox_scene
	if scene == null:
		return

	var delay := current_weapon.heavy_hitbox_delay
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout

	if !is_inside_tree() or stunned or !is_attacking or !is_heavy_attacking:
		return

	var inst := scene.instantiate()
	var hitbox := inst as Area2D
	if hitbox == null:
		push_error("Heavy hitbox scene root must be Area2D.")
		return

	if "spawner" in hitbox:
		hitbox.spawner = self

	get_parent().add_child(hitbox)

	var base_pos := hitbox_origin.global_position
	var offset := current_weapon.heavy_hitbox_offset
	hitbox.global_position = base_pos + _apply_dir_to_offset(offset, _get_attack_dir())

func play_attack_animation(anim_name: String):
	is_attacking = true
	is_heavy_attacking = false
	state = PlayerState.ATTACK

	if current_weapon != null:
		if current_weapon.has_method("get_lunge_speed"):
			attack_lunge_speed = float(current_weapon.get_lunge_speed(combo_step))
		if current_weapon.has_method("get_lunge_duration"):
			attack_lunge_timer = float(current_weapon.get_lunge_duration(combo_step))

	sprite.play(anim_name)

func start_light_attack(is_air: bool = false) -> void:
	_lock_attack_facing()

	if is_air:
		if current_weapon == null:
			return

		air_attack_used = true
		is_attacking = true
		is_heavy_attacking = false
		state = PlayerState.ATTACK

		var air_anim := "air_sword"
		if ("air_anim" in current_weapon) and String(current_weapon.air_anim) != "":
			air_anim = String(current_weapon.air_anim)

		current_air_anim = air_anim  # <--- IMPORTANT
		sprite.play(air_anim)

		spawn_hitbox(0)
		return

	# --------------------
	# GROUND (your existing code)
	# --------------------
	var max_hits := _weapon_max_combo_hits()

	if combo_timer > 0.0:
		combo_step += 1
	else:
		combo_step = 1

	if combo_step > max_hits:
		combo_step = 1

	combo_timer = combo_timeout

	var anim_name := _get_weapon_anim_for_step(combo_step)
	if anim_name == "":
		combo_step = 1
		anim_name = _get_weapon_anim_for_step(combo_step)
	if anim_name == "":
		return

	play_attack_animation(anim_name)
	spawn_hitbox(combo_step)

func start_heavy_attack() -> void:
	_lock_attack_facing()

	if current_weapon == null:
		return
	if not current_weapon.has_heavy:
		return
	if is_attacking or stunned or Blocking:
		return

	is_attacking = true
	is_heavy_attacking = true
	state = PlayerState.ATTACK

	play_sfx(sfx_heavy_attack)

	# Lunge from weapon
	attack_lunge_speed = current_weapon.heavy_lunge_speed
	attack_lunge_timer = current_weapon.heavy_lunge_duration

	# Play weapon heavy anim
	var heavy_anim := String(current_weapon.heavy_anim)
	if heavy_anim == "":
		heavy_anim = "heavy_attack"
	sprite.play(heavy_anim)

	# Spawn weapon heavy hitbox (scene + delay + offset)
	spawn_weapon_heavy_hitbox()

func take_damage(amount: int, attacker_pos: Vector2) -> void:
	var final_damage := amount
	var was_blocked := false

	var front_block_ok := _is_attack_from_front(attacker_pos)

	if Blocking and front_block_ok:
		was_blocked = true
		
		if block_frames <= PERFECT_BLOCK_FRAMES:
			final_damage = 0
			play_sfx(sfx_perfect_block)
			trigger_perfect_flash()
		else:
			final_damage = int(amount * block_damage_multiplier)
			play_sfx(sfx_perfect_block)
	else:
		final_damage = amount

	if final_damage > 0:
		stunned = true
		state = PlayerState.STUN
		stun_timer = stun_duration
		is_attacking = false
		is_dashing = false
		play_sfx(sfx_block)
		
		if not was_blocked:
			play_sfx(sfx_damage)

	health -= final_damage
	print("Damage taken:", final_damage, " Health:", health)

	if health <= 0:
		die()

func die():
	print("Character died")
	play_sfx(sfx_die)
	if die_reload_delay > 0.0:
		await get_tree().create_timer(die_reload_delay).timeout
	get_tree().reload_current_scene()

func start_dash():
	is_dashing = true
	state = PlayerState.DASH
	dash_timer = dash_duration
	cooldown_timer = dash_cooldown
	play_sfx(sfx_dash)

func end_dash():
	is_dashing = false
	state = PlayerState.IDLE

	if is_attacking:
		velocity.x = 0

func _on_animated_sprite_2d_animation_finished() -> void:
	if not is_attacking:
		return

	var finished := sprite.animation
	_dbg("animation_finished: %s | step=%d | queued=%s | buffer=%.2f"
		% [finished, combo_step, str(queued_light), buffer_timer])

	# --- AIR ATTACK END (NEW) ---
	if not is_heavy_attacking and current_air_anim != "" and finished == current_air_anim:
		is_attacking = false
		is_heavy_attacking = false
		attack_lunge_timer = 0.0
		current_air_anim = ""
		_unlock_attack_facing()
		return
	
	_dbg("animation_finished: %s | step=%d | queued=%s | buffer=%.2f"
		% [finished, combo_step, str(queued_light), buffer_timer])

		# Heavy ends combo (no chaining here)
	if is_heavy_attacking:
		var heavy_anim := "heavy_attack"
		if current_weapon != null:
			heavy_anim = String(current_weapon.heavy_anim)
			if heavy_anim == "":
				heavy_anim = "heavy_attack"

		if finished == heavy_anim:
			is_attacking = false
			is_heavy_attacking = false
			attack_lunge_timer = 0.0
			queued_light = false
			buffer_timer = 0.0
			current_air_anim = ""
			_unlock_attack_facing()
			return

	# Confirm we ended a light attack animation
	var ended_light := false
	if current_weapon != null and current_weapon.has_method("get_attack_anim"):
		for step in range(1, 6):
			if finished == String(current_weapon.get_attack_anim(step)):
				ended_light = true
				break
	if not ended_light:
		var f := finished.to_lower()
		if f.find("attack") != -1:
			ended_light = true

	if not ended_light:
		return

	# If buffered, chain to the next hit
	if queued_light and buffer_timer > 0.0 and not stunned and not Blocking:
		queued_light = false
		buffer_timer = 0.0

		# IMPORTANT: end current attack state first
		is_attacking = false
		is_heavy_attacking = false
		attack_lunge_timer = 0.0

		_dbg("Chaining -> start_light_attack() from finished=%s" % finished)
		start_light_attack()
		return

	# Otherwise end combo normally
	is_attacking = false
	is_heavy_attacking = false
	attack_lunge_timer = 0.0

func spawn_hitbox(combo: int) -> void:
	if current_weapon == null or current_weapon.hitbox_scene == null:
		_dbg("HITBOX: no weapon or no hitbox_scene")
		return

	# --- Delay from weapon ---
	var delay := 0.0
	if combo == 0:
	# AIR values (optional fields on WeaponData)
		if ("air_hitbox_delay" in current_weapon):
			delay = float(current_weapon.air_hitbox_delay)
	else:
		if current_weapon.has_method("get_hitbox_delay"):
			delay = float(current_weapon.get_hitbox_delay(combo))

	_dbg("HITBOX: step=%d delay=%.3f" % [combo, delay])

	if delay > 0.0:
		await get_tree().create_timer(delay).timeout

	# If you swapped/cancelled during delay, don't spawn
	if !is_attacking or stunned or Blocking:
		_dbg("HITBOX: cancelled after delay (is_attacking=%s stunned=%s block=%s)" %
			[str(is_attacking), str(stunned), str(Blocking)])
		return

	# --- Instantiate safely ---
	var inst := current_weapon.hitbox_scene.instantiate()
	if inst == null:
		push_error("Hitbox scene failed to instantiate. Check WeaponData.hitbox_scene.")
		return

	var hitbox := inst as Area2D
	if hitbox == null:
		push_error("Hitbox scene root must be Area2D.")
		return

	if "spawner" in hitbox:
		hitbox.spawner = self

	get_parent().add_child(hitbox)

	var offset := Vector2.ZERO
	if current_weapon.has_method("get_hitbox_offset"):
		offset = current_weapon.get_hitbox_offset(combo)

	var base_pos := hitbox_origin.global_position
	hitbox.global_position = base_pos + _apply_dir_to_offset(offset, _get_attack_dir())

	var hb: Hitbox = null
	if hitbox is Hitbox:
		hb = hitbox as Hitbox

	if hb != null:
		hb.spawner = self

		# 1) Compute values FIRST
		var shape: Shape2D = null
		var dmg: int = 0
		var stance_dmg: int = 0
		var kb: Vector2 = Vector2.ZERO
		var life: float = 0.12

		if combo == 0:
			shape = (current_weapon.air_hitbox_shape if ("air_hitbox_shape" in current_weapon) else null)
			dmg = (int(current_weapon.air_damage) if ("air_damage" in current_weapon) else current_weapon.get_damage(1))
			stance_dmg = (int(current_weapon.air_stance_damage) if ("air_stance_damage" in current_weapon) else current_weapon.get_stance_damage(1))
			kb = ( (current_weapon.air_knockback if ("air_knockback" in current_weapon) else current_weapon.get_knockback(1))
				* Vector2(_get_attack_dir(), 1) )
			life = (float(current_weapon.air_hitbox_lifetime) if ("air_hitbox_lifetime" in current_weapon) else 0.12)
		else:
			shape = current_weapon.get_hitbox_shape(combo)
			dmg = current_weapon.get_damage(combo)
			stance_dmg = current_weapon.get_stance_damage(combo)
			kb = current_weapon.get_knockback(combo) * Vector2(_get_attack_dir(), 1)
			life = current_weapon.get_hitbox_lifetime(combo)

		# 2) THEN configure
		hb.configure(
			null, # vfx (optional)
			null, # sfx (optional)
			Vector2.ZERO, # extra offset if your Hitbox uses it
			shape,
			dmg,
			stance_dmg,
			kb,
			life
		)
