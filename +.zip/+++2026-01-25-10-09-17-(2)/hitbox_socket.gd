extends Node2D

@export var hitbox_scene: PackedScene
@onready var hitbox_socket: Node2D = $HitboxSocket


func spawn_hitbox(combo: int) -> void:
	if hitbox_scene == null: return

	var hitbox: Area2D = hitbox_scene.instantiate()
	hitbox.spawner = self
	add_child(hitbox)

	hitbox.global_position = hitbox_socket.global_position
