extends Control

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.08, 0.08, 0.08)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vbox := VBoxContainer.new()
	vbox.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	vbox.add_theme_constant_override("separation", 24)
	add_child(vbox)

	var title := Label.new()
	title.text = "Scene Select"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	var btn_world := Button.new()
	btn_world.text = "World"
	btn_world.custom_minimum_size = Vector2(220.0, 55.0)
	btn_world.pressed.connect(func() -> void:
		get_tree().change_scene_to_file("res://Scenes/world.tscn"))
	vbox.add_child(btn_world)

	var btn_tunnel := Button.new()
	btn_tunnel.text = "Drill"
	btn_tunnel.custom_minimum_size = Vector2(220.0, 55.0)
	btn_tunnel.pressed.connect(func() -> void:
		get_tree().change_scene_to_file("res://Animations/IdleAni/drill.tscn"))
	vbox.add_child(btn_tunnel)
