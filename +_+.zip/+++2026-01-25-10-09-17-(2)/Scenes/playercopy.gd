extends CharacterBody2D


@onready var audio_stream_player: AudioStreamPlayer = $AudioStreamPlayer
@onready var hitbox_origin: Node2D = $HitboxOrigin


@export var combo_buffer_time: float = 1.25
var queued_light: bool = false
var buffer_timer: float = 0.8
var current_air_anim: String = ""

var attack_facing_dir: int = 1         
var attack_facing_locked: bool = false

# -------------------------
# SFX (assign in Inspector)
# -------------------------
@export var sfx_damage: AudioStream
@export var sfx_die: AudioStream
@export var sfx_dash: AudioStream
@export var sfx_heavy_attack: AudioStream
@export var sfx_perfect_block: AudioStream
@export var sfx_land: AudioStream
@export var sfx_block: AudioStream


# Optional: lets the death sound play a tiny bit before reloading
@export var die_reload_delay: float = 0.15

func play_sfx(stream: AudioStream) -> void:
	if stream == null:
		return
	# If you want overlapping sounds, set AudioStreamPlayer "Polyphony" > 1 in the Inspector.
	audio_stream_player.stream = stream
	audio_stream_player.play()

# Movement
@export var move_speed: float = 678.0
@export var air_acceleration: float = 5600.0  ## Horizontal ramp speed while airborne — lower = more floaty dash-jumps
@export var jump_force: float = 1250.0
@export var gravity: float = 2900.0
@export var max_step_height: float = 10.0
@export var step_checks: int = 5
@export var step_only_when_on_floor := true
@export var wall_slide_speed: float = 260.0       ## Max fall speed while sliding down a wall
@export var fast_fall_unlock_time: float = .27   ## Seconds airborne before the fast-fall window opens
@export var fast_fall_window: float = 0.05        ## How long the input window stays open
@export var fast_fall_speed: float = 2200.0       ## Downward velocity applied on fast-fall
var _air_time: float = 0.0
var _fast_fall_window_timer: float = 0.0
var _is_fast_falling: bool = false
@export var wall_jump_force_x: float = 520.0      ## Horizontal push away from wall on jump
@export var wall_jump_force_y: float = 1300.0     ## Vertical force on wall jump
@export var wall_jump_lock_time: float = 0.25     ## Seconds player can't steer back into wall after jumping


# Dash
@export var dash_speed: float = 1800.0
@export var dash_duration: float = 0.17
@export var dash_cooldown: float = 0.17
@export var enemy_physics_layer: int = 2  ## Layer enemies occupy — disabled on player during dash
@export var dash_passthrough_enabled: bool = true  ## Toggle enemy pass-through on dash
@export var dash_passthrough_duration: float = 0.4  ## Seconds the pass-through lasts after dash starts
var is_dashing: bool = false
var dash_timer: float = 0.0
var cooldown_timer: float = 0.0
var last_direction: int = 1
var _pre_dash_collision_mask: int = 0
var _pre_dash_collision_layer: int = 0
var _passthrough_active: bool = false
var _passthrough_timer: float = 0.0
var wall_jump_lock_timer: float = 0.0
var wall_jump_normal_x: float = 0.0  # wall normal X at moment of jump (used to block steering back)

# Combat / Health
var health: int = 100
var facing_right: bool = true
var is_attacking: bool = false
@export var block_move_multiplier: float = 0.5
@export var attack_move_multiplier: float = 1.70  ## Speed fraction applied when attacking but lunge has expired
@export var block_front_tolerance_px: float = 6.0

enum PlayerState { IDLE, RUN, JUMP, FALL, DASH, ATTACK, BLOCK, STUN, CROUCH }
var state: PlayerState = PlayerState.IDLE

var is_crouching: bool = false

@export var perfect_flash_time: float = 1.08
@export var perfect_flash_color: Color = Color(1, 1, 1, 1)
var _flash_timer: float = 0.0
var _flash_active: bool = false
var _base_modulate: Color

# Heavy attack
var is_heavy_attacking: bool = false
var was_on_floor: bool = false
@export var weapons: Array[WeaponData] = []
var weapon_index: int = 0
var current_weapon: WeaponData

# Equipment
@export var starting_equipment: Array[EquipmentData] = []
var equipped: Dictionary = {}          # EquipmentData.Slot (int) -> EquipmentData
var _equipment_defense_mult: float = 1.0   # combined defense multiplier from all equipped items
var _equipment_damage_mult: float = 1.0    # combined damage multiplier from all equipped items

# Base stats — stored so recalculation is always relative to the designer values
var _base_move_speed: float
var _base_jump_force: float
var _base_dash_speed: float
var _base_dash_cooldown: float
var _base_health: int
var _base_block_damage_multiplier: float

# Blocking
var Blocking: bool = false
var block_frames: int = 0
const BLOCK_DURATION_FRAMES := 10
const PERFECT_BLOCK_FRAMES := 12
@export var block_damage_multiplier := 0.25
var perfect_block_cooldown: int = 0  # frames remaining before perfect block window can reset
var block_hit_timer: float = 0.0     # plays "block_hit" animation briefly after absorbing a hit

# Stun
var stunned: bool = false
var stun_timer: float = 0.0
@export var stun_duration: float = 0.25

var combo_step: int = 0
@export var combo_timeout: float = 1.5
var combo_timer: float = 1.5
var air_attack_used := false

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

var attack_lunge_timer := 0.0
var attack_lunge_speed := 0.0
@export var debug_attacks: bool = true





func _dbg(msg: String) -> void:
	if debug_attacks:
		print("[ATTACK DBG] ", msg)


func _ready() -> void:
	add_to_group("player")
	set_collision_mask_value(enemy_physics_layer, false)
	floor_snap_length = max_step_height

	_dbg("SpriteFrames resource path: %s" % (sprite.sprite_frames.resource_path))
	_base_modulate = sprite.modulate

	if not sprite.animation_finished.is_connected(_on_animated_sprite_2d_animation_finished):
		sprite.animation_finished.connect(_on_animated_sprite_2d_animation_finished)

	if weapons.size() > 0:
		equip_weapon(0)

	# Cache base stats before any equipment is applied
	_base_move_speed            = move_speed
	_base_jump_force            = jump_force
	_base_dash_speed            = dash_speed
	_base_dash_cooldown         = dash_cooldown
	_base_health                = health
	_base_block_damage_multiplier = block_damage_multiplier

	for item in starting_equipment:
		equip_item(item)
		

func _physics_process(delta: float) -> void:
	if _process_stun(delta):
		return

	if not is_on_floor():
		velocity.y += gravity * delta
	apply_wall_slide(delta)

	_tick_combo_timer(delta)
	_tick_flash(delta)
	if block_hit_timer > 0.0:
		block_hit_timer -= delta

	var input_direction := Input.get_action_strength("Right") - Input.get_action_strength("Left")

	_handle_facing_input(input_direction)
	_handle_weapon_switch()
	_handle_dash(delta, input_direction)
	# Lunge runs AFTER _handle_dash so it can override velocity only when player has no input.
	# When the player presses movement while attacking, attack_move_multiplier wins instead.
	_tick_attack_lunge(delta, input_direction)
	_handle_crouch()
	_push_off_characters()
	_handle_jump()

	Blocking = Input.is_action_pressed("Block")
	_handle_block_input()
	_handle_fast_fall(delta)

	move_with_step(delta)
	_handle_landing()

	update_state(input_direction)
	update_animation()

	_tick_buffer_timer(delta)


func _process_stun(delta: float) -> bool:
	if not stunned:
		return false

	stun_timer -= delta
	velocity.x = 0

	if not is_on_floor():
		velocity.y += gravity * delta

	apply_wall_slide(delta)
	_push_off_characters()
	move_with_step(delta)
	_handle_landing()
	_tick_flash(delta)

	if stun_timer <= 0.0:
		stunned = false
	return true


func _tick_flash(delta: float) -> void:
	if not _flash_active:
		return
	_flash_timer -= delta
	if _flash_timer <= 0.0:
		_flash_active = false
		sprite.modulate = _base_modulate


func _tick_combo_timer(delta: float) -> void:
	if combo_timer > 0.0:
		combo_timer -= delta
	else:
		combo_step = 0


func _tick_attack_lunge(delta: float, input_direction: float) -> void:
	if is_attacking and attack_lunge_timer > 0.0:
		attack_lunge_timer -= delta
		# Only push with lunge speed when the player has no directional input.
		# If they are pressing movement, attack_move_multiplier (set in _handle_dash) takes priority.
		if input_direction == 0.0:
			velocity.x = last_direction * attack_lunge_speed


func _handle_facing_input(input_direction: float) -> void:
	if input_direction != 0.0:
		last_direction = int(sign(input_direction))
		facing_right = (last_direction == 1)
		sprite.flip_h = not facing_right


func _handle_weapon_switch() -> void:
	if Input.is_action_just_pressed("NextWeapon"):
		if !is_attacking and !is_dashing:
			equip_weapon(weapon_index + 1)
	if Input.is_action_just_pressed("PrevWeapon"):
		if !is_attacking and !is_dashing:
			equip_weapon(weapon_index - 1)


func _handle_dash(delta: float, input_direction: float) -> void:
	if Input.is_action_just_pressed("Dash") and not is_dashing and not is_crouching and cooldown_timer <= 0.0:
		start_dash()

	if wall_jump_lock_timer > 0.0:
		wall_jump_lock_timer -= delta

	if _passthrough_active:
		_passthrough_timer -= delta
		if _passthrough_timer <= 0.0:
			_end_passthrough()

	if is_dashing:
		dash_timer -= delta
		if dash_timer <= 0.0 or not Input.is_action_pressed("Dash"):
			end_dash()
		else:
			velocity.x = last_direction * dash_speed
	else:
		var speed_mult: float
		if is_attacking:
			speed_mult = attack_move_multiplier
		elif Blocking:
			speed_mult = block_move_multiplier
		else:
			speed_mult = 1.0
		var desired_x := input_direction * move_speed * speed_mult
		# Block steering back into the wall for wall_jump_lock_time seconds
		if wall_jump_lock_timer > 0.0 and sign(desired_x) != sign(wall_jump_normal_x):
			desired_x = 0.0
		if is_on_floor():
			velocity.x = desired_x
		else:
			velocity.x = move_toward(velocity.x, desired_x, air_acceleration * delta)
		cooldown_timer -= delta


func _handle_crouch() -> void:
	var wants_crouch := (
		Input.is_action_pressed("Crouch")
		and is_on_floor()
		and not is_attacking
		and not is_dashing
		and not stunned
		and not Blocking
	)
	is_crouching = wants_crouch
	if is_crouching:
		velocity.x = 0.0


func _push_off_characters() -> void:
	for i in get_slide_collision_count():
		var col: KinematicCollision2D = get_slide_collision(i)
		# normal.y < -0.7 means this collision is pushing us upward — we are on top of the collider
		if col.get_normal().y < -0.7 and col.get_collider() is CharacterBody2D:
			var other := col.get_collider() as CharacterBody2D
			var push_dir: float = sign(global_position.x - other.global_position.x)
			if push_dir == 0:
				push_dir = last_direction
			velocity.x = push_dir * move_speed
			velocity.y = 0.0
			return


func _handle_jump() -> void:
	if is_crouching:
		return
	if not Input.is_action_just_pressed("Up"):
		return
	if is_on_floor():
		velocity.y = -jump_force
	elif _is_on_wall_only() and not stunned and not is_dashing:
		var n := get_wall_normal()
		velocity.x = n.x * wall_jump_force_x
		velocity.y = -wall_jump_force_y
		# Flip to face away from wall
		facing_right = n.x > 0
		sprite.flip_h = not facing_right
		last_direction = int(sign(n.x))
		# Lock steering for a moment so player doesn't snap back into wall
		wall_jump_lock_timer = wall_jump_lock_time
		wall_jump_normal_x = n.x


func _handle_block_input() -> void:
	if perfect_block_cooldown > 0:
		perfect_block_cooldown -= 1
	if Input.is_action_just_pressed("Block"):
		if perfect_block_cooldown <= 0:
			block_frames = 0
	if Blocking:
		block_frames += 1


func _handle_landing() -> void:
	var now_on_floor := is_on_floor()
	if now_on_floor and not was_on_floor:
		play_sfx(sfx_land)
	was_on_floor = now_on_floor
	if now_on_floor:
		air_attack_used = false
		_air_time = 0.0
		_fast_fall_window_timer = 0.0
		_is_fast_falling = false


func _handle_fast_fall(delta: float) -> void:
	if is_on_floor() or stunned or is_dashing:
		return

	_air_time += delta

	# Open the window once, exactly at the unlock time
	if _air_time >= fast_fall_unlock_time and _fast_fall_window_timer <= 0.0 and not _is_fast_falling:
		_fast_fall_window_timer = fast_fall_window

	# Tick the window and listen for input
	if _fast_fall_window_timer > 0.0:
		_fast_fall_window_timer -= delta
		if Input.is_action_just_pressed("Crouch"):
			_is_fast_falling = true
			_fast_fall_window_timer = 0.0

	if _is_fast_falling:
		velocity.x = 0.0
		velocity.y = fast_fall_speed


func _tick_buffer_timer(delta: float) -> void:
	if queued_light and is_attacking:
		buffer_timer -= delta
		if buffer_timer <= 0.0:
			queued_light = false
			buffer_timer = 0.0

func trigger_perfect_flash():
	_flash_active = true
	_flash_timer = perfect_flash_time
	sprite.modulate = perfect_flash_color
	
func _get_attack_dir() -> int:
	# If we locked facing for this attack, use it.
	# Otherwise use current facing.
	if attack_facing_locked:
		return attack_facing_dir
	return 1 if facing_right else -1

func _apply_dir_to_offset(offset: Vector2, dir: int) -> Vector2:
	# Flip X only, keep Y unchanged
	return Vector2(offset.x * dir, offset.y)

func _lock_attack_facing() -> void:
	# Lock the direction the instant an attack starts.
	# Prefer last_direction if it's valid, otherwise use facing_right.
	attack_facing_dir = (last_direction if last_direction != 0 else (1 if facing_right else -1))
	attack_facing_locked = true

func _unlock_attack_facing() -> void:
	attack_facing_locked = false
	attack_facing_dir = 1	


# ── Equipment ────────────────────────────────────────────────────────────────

## Equip an item.  Replaces any item already in the same slot.
func equip_item(item: EquipmentData) -> void:
	if item == null:
		return
	equipped[item.slot] = item
	_recalculate_equipment_stats()

## Remove the item in the given slot (if any).
func unequip_item(slot: EquipmentData.Slot) -> void:
	equipped.erase(slot)
	_recalculate_equipment_stats()

## Returns the item in the given slot, or null if empty.
func get_equipped_item(slot: EquipmentData.Slot) -> EquipmentData:
	return equipped.get(slot, null)

func _recalculate_equipment_stats() -> void:
	var speed_mult       := 1.0
	var jump_bonus       := 0.0
	var dash_bonus       := 0.0
	var dash_cd_reduce   := 0.0
	var health_bonus     := 0
	var defense_mult     := 1.0
	var block_bonus      := 0.0

	var damage_mult      := 1.0

	for item: EquipmentData in equipped.values():
		speed_mult     *= item.speed_multiplier
		jump_bonus     += item.jump_force_bonus
		dash_bonus     += item.dash_speed_bonus
		dash_cd_reduce += item.dash_cooldown_reduction
		health_bonus   += item.health_bonus
		defense_mult   *= item.defense_multiplier
		block_bonus    += item.block_damage_multiplier_bonus
		damage_mult    *= item.damage_multiplier

	move_speed              = _base_move_speed * speed_mult
	jump_force              = _base_jump_force + jump_bonus
	dash_speed              = _base_dash_speed + dash_bonus
	dash_cooldown           = maxf(0.0, _base_dash_cooldown - dash_cd_reduce)
	health                  = _base_health + health_bonus
	block_damage_multiplier = maxf(0.0, _base_block_damage_multiplier - block_bonus)
	_equipment_defense_mult = defense_mult
	_equipment_damage_mult  = damage_mult

# ─────────────────────────────────────────────────────────────────────────────

func equip_weapon(index: int) -> void:
	if weapons.is_empty():
		current_weapon = null
		return

	var i := wrapi(index, 0, weapons.size())
	var tries := 0
	while tries < weapons.size() and weapons[i] == null:
		i = wrapi(i + 1, 0, weapons.size())
		tries += 1

	if weapons[i] == null:
		push_warning("All weapon slots are null.")
		current_weapon = null
		return

	weapon_index = i
	current_weapon = weapons[weapon_index]

func move_with_step(delta: float) -> void:
	if step_only_when_on_floor and !is_on_floor():
		move_and_slide()
		return

	if is_attacking:
		move_and_slide()
		return

	var want_step: bool = absf(velocity.x) > 0.01
	var was_on_floor: bool = is_on_floor()
	var old_pos: Vector2 = global_position

	move_and_slide()

	if !want_step:
		return

	var intended_x: float = absf(velocity.x * delta)
	var actual_x: float = absf(global_position.x - old_pos.x)

	if intended_x <= 0.001 or actual_x >= intended_x * 0.75:
		return

	if step_only_when_on_floor and !was_on_floor:
		return

	global_position = old_pos

	var checks: int = max(step_checks, 1)
	var step_height: float = max_step_height / float(checks)

	for i in range(checks):
		var up: float = step_height * float(i + 1)
		global_position = old_pos + Vector2(0.0, -up)
		move_and_slide()
		actual_x = absf(global_position.x - old_pos.x)
		if actual_x >= intended_x * 0.75:
			return

	global_position = old_pos
	move_and_slide()

@warning_ignore("unused_parameter")
func update_state(input_direction: float) -> void:
	if stunned:
		state = PlayerState.STUN
		return
	if is_dashing:
		state = PlayerState.DASH
		return
	if is_attacking:
		state = PlayerState.ATTACK
		return
	if Blocking:
		state = PlayerState.BLOCK
		return
	if is_crouching:
		state = PlayerState.CROUCH
		return

	if not is_on_floor():
		if velocity.y < 0.0:
			state = PlayerState.JUMP
		else:
			state = PlayerState.FALL
		return

	if absf(input_direction) > 0.01:
		state = PlayerState.RUN
	else:
		state = PlayerState.IDLE

func play_anim(name: String) -> void:
	if sprite.animation != name:
		sprite.play(name)

func _is_on_wall_only() -> bool:
	return is_on_wall() and not is_on_floor()

func _wall_side_dir() -> int:
	# Returns -1 if wall is on right (normal points left), +1 if wall is on left (normal points right)
	var n := get_wall_normal()
	if n == Vector2.ZERO:
		return 0
	return int(sign(n.x))
	
func apply_wall_slide(delta: float) -> void:
	if not _is_on_wall_only():
		return
	if velocity.y <= 0.0:
		return
	if is_dashing or stunned or is_attacking or Blocking:
		return
	if wall_jump_lock_timer > 0.0:
		return

	# wdir is the wall normal X (+1 = wall on left, -1 = wall on right).
	# Pressing INTO the wall means pressing opposite to the normal.
	var input_dir := Input.get_action_strength("Right") - Input.get_action_strength("Left")
	var wdir := _wall_side_dir()
	var pressing_into := (input_dir != 0.0 and int(sign(input_dir)) == -wdir)
	if not pressing_into:
		return

	velocity.y = min(velocity.y, wall_slide_speed)

func _weapon_max_combo_hits() -> int:
	if current_weapon == null:
		return 0
	return current_weapon.get_max_combo_hits()


func _get_weapon_anim_for_step(step: int) -> String:
	if current_weapon == null:
		return ""
	if step > current_weapon.get_max_combo_hits():
		return ""
	var anim := String(current_weapon.get_attack_anim(step))
	if anim == "":
		return ""
	if sprite.sprite_frames != null and not sprite.sprite_frames.has_animation(anim):
		push_warning("WeaponData references missing animation '%s'" % anim)
		return ""
	_dbg("Attack step=%d -> anim=%s" % [step, anim])
	return anim
	


func _is_attack_from_front(attacker_pos: Vector2) -> bool:
	var origin_x := hitbox_origin.global_position.x if hitbox_origin else global_position.x
	var dx := attacker_pos.x - origin_x
	if absf(dx) <= block_front_tolerance_px:
		return true
	return dx > 0.0 if facing_right else dx < 0.0
		


func update_animation() -> void:
	# If we're NOT attacking, play locomotion animations
	if not is_attacking:
		match state:
			PlayerState.IDLE:  play_anim("idle")
			PlayerState.RUN:   play_anim("walk")
			PlayerState.JUMP:  play_anim("jump")
			PlayerState.FALL:  play_anim("fall")
			PlayerState.DASH:  play_anim("run")
			PlayerState.BLOCK:
				if block_hit_timer > 0.0:
					play_anim("block_hit")
				elif is_on_floor():
					play_anim("block")
				else:
					play_anim("block_air")
			PlayerState.STUN:   play_anim("stun")
			PlayerState.CROUCH: play_anim("crouch")
			PlayerState.ATTACK:
				pass

	# --- Light attack input (buffered) ---
	if Input.is_action_just_pressed("Attack") and not stunned and not Blocking:
		if not is_on_floor():
			# Air attack: one per airtime, no combo buffering
			if not is_attacking and not air_attack_used:
				start_light_attack(true)
		else:
			# Ground attack: your existing combo buffering
			if is_attacking:
				if not queued_light:
					_dbg("Queued next light hit (current step=%d)" % combo_step)
				queued_light = true
				buffer_timer = combo_buffer_time
			else:
				start_light_attack(false)

	# --- Heavy attack input ---
	if Input.is_action_just_pressed("Heavy") and not is_attacking and not stunned and not Blocking:
		start_heavy_attack()
		
		
func spawn_weapon_heavy_hitbox() -> void:
	if current_weapon == null:
		return

	var scene := current_weapon.heavy_hitbox_scene if current_weapon.heavy_hitbox_scene != null else current_weapon.hitbox_scene
	if scene == null:
		return

	var delay := current_weapon.heavy_hitbox_delay
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout

	if !is_inside_tree() or stunned or !is_attacking or !is_heavy_attacking:
		return

	var inst := scene.instantiate()
	var hitbox := inst as Area2D
	if hitbox == null:
		push_error("Heavy hitbox scene root must be Area2D.")
		return

	if "spawner" in hitbox:
		hitbox.spawner = self

	get_parent().add_child(hitbox)

	var base_pos := hitbox_origin.global_position
	var offset := current_weapon.heavy_hitbox_offset
	hitbox.global_position = base_pos + _apply_dir_to_offset(offset, _get_attack_dir())

	if hitbox is Hitbox:
		var hb := hitbox as Hitbox
		hb.spawner = self
		hb.configure(
			null,
			null,
			Vector2.ZERO,
			current_weapon.heavy_hitbox_shape,
			int(current_weapon.heavy_damage * _equipment_damage_mult),
			current_weapon.heavy_stance_damage,
			current_weapon.heavy_knockback * Vector2(_get_attack_dir(), 1),
			current_weapon.heavy_hitbox_lifetime
		)

func play_attack_animation(anim_name: String) -> void:
	is_attacking = true
	is_heavy_attacking = false
	state = PlayerState.ATTACK
	attack_lunge_speed = float(current_weapon.get_lunge_speed(combo_step))
	attack_lunge_timer = float(current_weapon.get_lunge_duration(combo_step))
	play_sfx(current_weapon.attack_sfx)
	sprite.play(anim_name)

func start_light_attack(is_air: bool = false) -> void:
	_lock_attack_facing()

	if is_air:
		if current_weapon == null:
			return

		air_attack_used = true
		is_attacking = true
		is_heavy_attacking = false
		state = PlayerState.ATTACK

		var air_anim := "air_sword"
		if ("air_anim" in current_weapon) and String(current_weapon.air_anim) != "":
			air_anim = String(current_weapon.air_anim)

		current_air_anim = air_anim  # <--- IMPORTANT
		play_sfx(current_weapon.attack_sfx)
		sprite.play(air_anim)

		spawn_hitbox(0)
		return

	# --------------------
	# GROUND (your existing code)
	# --------------------
	var max_hits := _weapon_max_combo_hits()

	if combo_timer > 0.0:
		combo_step += 1
	else:
		combo_step = 1

	if combo_step > max_hits:
		combo_step = 1

	combo_timer = combo_timeout

	var anim_name := _get_weapon_anim_for_step(combo_step)
	if anim_name == "":
		combo_step = 1
		anim_name = _get_weapon_anim_for_step(combo_step)
	if anim_name == "":
		return

	play_attack_animation(anim_name)
	spawn_hitbox(combo_step)

func start_heavy_attack() -> void:
	_lock_attack_facing()

	if current_weapon == null:
		return
	if not current_weapon.has_heavy:
		return
	if is_attacking or stunned or Blocking:
		return

	is_attacking = true
	is_heavy_attacking = true
	state = PlayerState.ATTACK

	play_sfx(current_weapon.heavy_attack_sfx if current_weapon.heavy_attack_sfx != null else sfx_heavy_attack)

	# Lunge from weapon
	attack_lunge_speed = current_weapon.heavy_lunge_speed
	attack_lunge_timer = current_weapon.heavy_lunge_duration

	# Play weapon heavy anim
	var heavy_anim := String(current_weapon.heavy_anim)
	if heavy_anim == "":
		heavy_anim = "heavy_attack"
	sprite.play(heavy_anim)

	# Spawn weapon heavy hitbox (scene + delay + offset)
	spawn_weapon_heavy_hitbox()

func apply_knockback(kb: Vector2, _attacker_pos: Vector2) -> void:
	velocity = kb

func take_damage(amount: int, attacker_pos: Vector2) -> void:
	var final_damage := int(amount * _equipment_defense_mult)
	var was_blocked := false

	var front_block_ok := _is_attack_from_front(attacker_pos)

	if Blocking and front_block_ok:
		was_blocked = true
		block_hit_timer = 0.35
		if block_frames <= PERFECT_BLOCK_FRAMES and perfect_block_cooldown <= 0:
			final_damage = 0
			play_sfx(sfx_perfect_block)
			trigger_perfect_flash()
			perfect_block_cooldown = 4
		else:
			final_damage = int(amount * block_damage_multiplier)
			play_sfx(sfx_perfect_block)
	else:
		final_damage = amount

	if final_damage > 0:
		stunned = true
		state = PlayerState.STUN
		stun_timer = stun_duration
		is_attacking = false
		if is_dashing:
			end_dash()
		play_sfx(sfx_block)
		
		if not was_blocked:
			play_sfx(sfx_damage)

	health -= final_damage
	print("Damage taken:", final_damage, " Health:", health)

	if health <= 0:
		die()

func die():
	print("Character died")
	play_sfx(sfx_die)
	if die_reload_delay > 0.0:
		await get_tree().create_timer(die_reload_delay).timeout
	get_tree().reload_current_scene()

func start_dash():
	is_dashing = true
	dash_timer = dash_duration
	state = PlayerState.DASH
	cooldown_timer = dash_cooldown
	play_sfx(sfx_dash)
	if dash_passthrough_enabled:
		_pre_dash_collision_mask = collision_mask
		_pre_dash_collision_layer = collision_layer
		set_collision_mask_value(enemy_physics_layer, false)
		set_collision_layer_value(enemy_physics_layer, false)
		_passthrough_active = true
		_passthrough_timer = dash_passthrough_duration

func _end_passthrough() -> void:
	if not _passthrough_active:
		return
	_passthrough_active = false
	_passthrough_timer = 0.0
	collision_mask = _pre_dash_collision_mask
	collision_layer = _pre_dash_collision_layer

func end_dash():
	is_dashing = false
	state = PlayerState.IDLE
	_end_passthrough()

	if is_attacking:
		velocity.x = 0

func _on_animated_sprite_2d_animation_finished() -> void:
	if not is_attacking:
		return

	var finished := sprite.animation
	_dbg("animation_finished: %s | step=%d | queued=%s | buffer=%.2f"
		% [finished, combo_step, str(queued_light), buffer_timer])

	# --- AIR ATTACK END ---
	if not is_heavy_attacking and current_air_anim != "" and finished == current_air_anim:
		is_attacking = false
		is_heavy_attacking = false
		attack_lunge_timer = 0.0
		current_air_anim = ""
		_unlock_attack_facing()
		return

	# Heavy ends combo (no chaining here)
	if is_heavy_attacking:
		var heavy_anim := "heavy_attack"
		if current_weapon != null:
			heavy_anim = String(current_weapon.heavy_anim)
			if heavy_anim == "":
				heavy_anim = "heavy_attack"

		if finished == heavy_anim:
			is_attacking = false
			is_heavy_attacking = false
			attack_lunge_timer = 0.0
			queued_light = false
			buffer_timer = 0.0
			current_air_anim = ""
			_unlock_attack_facing()
			return

	# Confirm we ended a light attack animation
	var ended_light := false
	if current_weapon != null and current_weapon.has_method("get_attack_anim"):
		for step in range(1, 6):
			if finished == String(current_weapon.get_attack_anim(step)):
				ended_light = true
				break
	if not ended_light:
		var f := finished.to_lower()
		if f.find("attack") != -1:
			ended_light = true

	if not ended_light:
		return

	# If buffered, chain to the next hit
	if queued_light and buffer_timer > 0.0 and not stunned and not Blocking:
		queued_light = false
		buffer_timer = 0.0

		# IMPORTANT: end current attack state first
		is_attacking = false
		is_heavy_attacking = false
		attack_lunge_timer = 0.0

		_dbg("Chaining -> start_light_attack() from finished=%s" % finished)
		start_light_attack()
		return

	# Otherwise end combo normally
	is_attacking = false
	is_heavy_attacking = false
	attack_lunge_timer = 0.0

func spawn_hitbox(combo: int) -> void:
	if current_weapon == null or current_weapon.hitbox_scene == null:
		_dbg("HITBOX: no weapon or no hitbox_scene")
		return

	# --- Delay from weapon ---
	var delay := 0.0
	if combo == 0:
		delay = current_weapon.air_hitbox_delay
	else:
		if current_weapon.has_method("get_hitbox_delay"):
			delay = float(current_weapon.get_hitbox_delay(combo))

	_dbg("HITBOX: step=%d delay=%.3f" % [combo, delay])

	if delay > 0.0:
		await get_tree().create_timer(delay).timeout

	# If you swapped/cancelled during delay, don't spawn
	if !is_attacking or stunned or Blocking:
		_dbg("HITBOX: cancelled after delay (is_attacking=%s stunned=%s block=%s)" %
			[str(is_attacking), str(stunned), str(Blocking)])
		return

	# --- Instantiate safely ---
	var inst := current_weapon.hitbox_scene.instantiate()
	if inst == null:
		push_error("Hitbox scene failed to instantiate. Check WeaponData.hitbox_scene.")
		return

	var hitbox := inst as Area2D
	if hitbox == null:
		push_error("Hitbox scene root must be Area2D.")
		return

	if "spawner" in hitbox:
		hitbox.spawner = self

	get_parent().add_child(hitbox)

	var offset := current_weapon.air_hitbox_offset if combo == 0 else (
		current_weapon.get_hitbox_offset(combo) if current_weapon.has_method("get_hitbox_offset") else Vector2.ZERO)

	var base_pos := hitbox_origin.global_position
	hitbox.global_position = base_pos + _apply_dir_to_offset(offset, _get_attack_dir())

	var hb: Hitbox = null
	if hitbox is Hitbox:
		hb = hitbox as Hitbox

	if hb != null:
		hb.spawner = self

		var shape: Shape2D = null
		var dmg: int = 0
		var stance_dmg: int = 0
		var kb: Vector2 = Vector2.ZERO
		var life: float = 0.12

		if combo == 0:
			shape      = current_weapon.air_hitbox_shape
			dmg        = int((current_weapon.air_damage if current_weapon.air_damage > 0 else current_weapon.get_damage(1)) * _equipment_damage_mult)
			stance_dmg = current_weapon.air_stance_damage if current_weapon.air_stance_damage > 0 else current_weapon.get_stance_damage(1)
			kb         = (current_weapon.air_knockback if current_weapon.air_knockback != Vector2.ZERO else current_weapon.get_knockback(1)) * Vector2(_get_attack_dir(), 1)
			life       = current_weapon.air_hitbox_lifetime
		else:
			shape = current_weapon.get_hitbox_shape(combo)
			dmg = int(current_weapon.get_damage(combo) * _equipment_damage_mult)
			stance_dmg = current_weapon.get_stance_damage(combo)
			kb = current_weapon.get_knockback(combo) * Vector2(_get_attack_dir(), 1)
			life = current_weapon.get_hitbox_lifetime(combo)

		hb.configure(
			null, # vfx (optional)
			null, # sfx (optional)
			Vector2.ZERO, # extra offset if your Hitbox uses it
			shape,
			dmg,
			stance_dmg,
			kb,
			life
		)
