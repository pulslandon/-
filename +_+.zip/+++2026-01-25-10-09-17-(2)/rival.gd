extends CharacterBody2D

const ENEMY_LAYER := 2
@export var player_physics_layer: int = 1  ## Layer the player occupies — disabled on enemy while player dashes

@onready var hitbox_origin: Node2D = $HitboxOrigin
@export var max_health: int = 100
@export var max_stance: int = 100
var health: int
var stance: int
@export var stancedmg: int = 10

@export var gravity: float = 11100.0

@export var attack_interval: float = 0.7
var attack_timer: float = 0.0

# -------------------------
# Weapon-driven combat
# -------------------------
@export var weapon: WeaponData            # <-- assign in Inspector
var current_weapon: WeaponData = null

var is_attacking: bool = false
var is_heavy_attacking: bool = false
var attack_step: int = 0  # 1..max for light chain

# Combo / attack chain
@export var combo_chance := 0.75

var attack_lunge_timer := 0.0
var attack_lunge_speed := 0.0

# Heavy pick chance
@export_range(0.0, 1.0, 0.05) var heavy_chance := 0.25
@export var heavy_attack_interval_multiplier := 1.6

# -------------------------
# Facing / movement
# -------------------------
var facing_right := true
@export var move_speed: float = 620.0
@export var dash_speed: float = 680.0
@export var stop_distance: float = 20.0     ## How close the enemy must be before it stops walking into the player
@export var attack_range: float = 150.0     ## Maximum horizontal distance at which the enemy may attack
@export var state_change_interval: float = 0.3
@export var knockback_force := Vector2(300, -200)

var player: Node2D
var ai_state: String = "approach"
var state_timer: float = 0.0

# -------------------------
# Stun / block
# -------------------------
var stunned: bool = false
var stun_timer: float = 0.0
@export var stun_duration: float = 1.2

var is_blocking: bool = false
@export var block_duration := 1.0
var block_timer := 0.0

@export_range(0.0, 1.0, 0.05) var block_chance := 0.5
@export var block_on_success := true

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var health_bar: ProgressBar = $HealthBar


func _ready():
	player = get_tree().get_first_node_in_group("player")
	sprite.animation_finished.connect(_on_animation_finished)

	attack_timer = attack_interval

	health = max_health
	stance = max_stance
	_setup_health_bar()
	_update_health_bar()

	# Equip weapon
	current_weapon = weapon
	if current_weapon == null:
		push_warning("Enemy has no WeaponData assigned! Attacks will not spawn hitboxes.")


# -------------------------
# UI
# -------------------------
func _setup_health_bar() -> void:
	if health_bar == null:
		return
	health_bar.min_value = 0
	health_bar.max_value = max_health
	health_bar.value = health

func _update_health_bar() -> void:
	if health_bar == null:
		return
	health_bar.max_value = max_health
	health_bar.value = clamp(health, 0, max_health)


# -------------------------
# Animation
# -------------------------
func update_animation() -> void:
	if stunned:
		if sprite.animation != "hit":
			sprite.play("hit")
		return

	if is_blocking:
		if sprite.animation != "block":
			sprite.play("block")
		return

	if is_attacking:
		# attack anims are driven explicitly
		return

	# Movement / idle
	if ai_state == "dash":
		if sprite.animation != "run":
			sprite.play("run")
	elif absf(velocity.x) > 1.0:
		if sprite.animation != "walk":
			sprite.play("walk")
	else:
		if sprite.animation != "idle":
			sprite.play("idle")




# -------------------------
# Stance + Block
# -------------------------
func take_stance_damage(stance_damage: int = 0, attacker_position: Vector2 = Vector2.ZERO) -> void:
	var dmg := stance_damage if stance_damage > 0 else stancedmg
	if dmg <= 0:
		return

	stance = clamp(stance - dmg, 0, max_stance)
	print("Stance damaged:", dmg, " Stance:", stance)

	if stance <= 0:
		on_stance_broken(attacker_position)

func start_block(time: float = -1.0) -> void:
	if stunned:
		return

	# cancel attacks
	_end_attack()

	ai_state = "block"
	is_blocking = true
	block_timer = (block_duration if time < 0.0 else time)

	if sprite.animation != "block":
		sprite.play("block")

func end_block() -> void:
	is_blocking = false
	block_timer = 0.0
	if ai_state == "block":
		ai_state = "idle"
	sprite.play("idle")

func on_stance_broken(attacker_position: Vector2 = Vector2.ZERO) -> void:
	_end_attack()

	stunned = true
	stun_timer = max(stun_timer, stun_duration * 1.25)

	if attacker_position != Vector2.ZERO:
		var knock_dir = sign(global_position.x - attacker_position.x)
		velocity.x = knock_dir * knockback_force.x
		velocity.y = knockback_force.y

	print("STANCE BROKEN!")


# -------------------------
# Physics
# -------------------------
func _physics_process(delta: float) -> void:
	if player == null:
		return

	# While the player is dashing, remove the player's layer from this enemy's
	# collision mask so the enemy doesn't get blocked by the player's body.
	var player_dashing: bool = ("is_dashing" in player) and player.is_dashing
	set_collision_mask_value(player_physics_layer, not player_dashing)

	# STUN
	if stunned:
		stun_timer -= delta
		velocity.x = 0
		if not is_on_floor():
			velocity.y += gravity * delta
		_push_off_characters()
		move_and_slide()
		update_animation()
		if stun_timer <= 0.0:
			stunned = false
		return

	# BLOCK
	if is_blocking:
		velocity.x = 0
		block_timer -= delta
		if sprite.animation != "block":
			sprite.play("block")
		if not is_on_floor():
			velocity.y += gravity * delta
		_push_off_characters()
		move_and_slide()
		update_animation()
		if block_timer <= 0.0:
			end_block()
		return

	# AI state changes
	state_timer -= delta
	if state_timer <= 0.0 and !is_attacking:
		pick_new_state()

	# Movement
	if is_attacking:
		if attack_lunge_timer > 0.0:
			attack_lunge_timer -= delta
			var lunge_dir := 1 if facing_right else -1
			velocity.x = lunge_dir * attack_lunge_speed
		else:
			velocity.x = 0
	else:
		apply_behavior(delta)

	# Gravity
	if not is_on_floor():
		velocity.y += gravity * delta

	_push_off_characters()
	move_and_slide()
	update_animation()

	# Attack timer
	attack_timer -= delta
	if attack_timer <= 0.0:
		attack_timer = attack_interval
		perform_attack()


# -------------------------
# AI
# -------------------------
func pick_new_state():
	var dist := absf(player.global_position.x - global_position.x)

	var weighted_behaviors: Array
	if dist > attack_range:
		# Out of attack range — focus on closing the gap
		weighted_behaviors = [
			"approach", "approach", "approach",
			"dash",
			"idle",
		]
	else:
		# Inside attack range — allow full behavioural mix
		weighted_behaviors = [
			"approach", "approach",
			"retreat",
			"idle",
			"dash",
			"block",
		]

	ai_state = weighted_behaviors[randi() % weighted_behaviors.size()]
	state_timer = randf_range(state_change_interval * 1.0, state_change_interval * 2.0)

	if ai_state == "block" and !is_attacking:
		start_block(block_duration)

func _push_off_characters() -> void:
	for i in get_slide_collision_count():
		var col: KinematicCollision2D = get_slide_collision(i)
		# normal.y < -0.7 means we are resting on top of this collider
		if col.get_normal().y < -0.7 and col.get_collider() is CharacterBody2D:
			var other := col.get_collider() as CharacterBody2D
			var push_dir: float = sign(global_position.x - other.global_position.x)
			if push_dir == 0:
				push_dir = 1 if facing_right else -1
			velocity.x += push_dir * move_speed
			return


func apply_behavior(delta):
	var distance = player.global_position.x - global_position.x
	var direction = sign(distance)

	if direction != 0:
		facing_right = direction > 0
		sprite.flip_h = not facing_right

	match ai_state:
		"approach":
			if abs(distance) > stop_distance:
				velocity.x = direction * move_speed
			else:
				velocity.x = 0
		"retreat":
			velocity.x = -direction * move_speed
		"idle":
			velocity.x = 0
		"dash":
			velocity.x = direction * dash_speed
		"block":
			velocity.x = 0


# -------------------------
# Weapon-driven attacks
# -------------------------
func perform_attack():
	if is_attacking or stunned or is_blocking:
		return
	if current_weapon == null:
		return
	# Only attack when the player is within attack_range
	if absf(player.global_position.x - global_position.x) > attack_range:
		return

	# Decide heavy vs light
	var do_heavy := current_weapon.has_heavy and (randf() < heavy_chance)

	if do_heavy:
		_start_heavy_attack()
	else:
		_start_light_attack(1)

func _start_light_attack(step: int) -> void:
	is_attacking = true
	is_heavy_attacking = false
	attack_step = step

	var max_hits := current_weapon.get_max_combo_hits()
	if attack_step > max_hits:
		attack_step = 1

	var anim: StringName = current_weapon.get_attack_anim(attack_step)
	if String(anim) == "":
		# No such attack for this weapon
		_end_attack()
		return

	attack_lunge_speed = current_weapon.get_lunge_speed(attack_step)
	attack_lunge_timer = current_weapon.get_lunge_duration(attack_step)

	sprite.play(String(anim))

	# Spawn hitbox for this step
	var delay := current_weapon.get_hitbox_delay(attack_step)
	var offset := current_weapon.get_hitbox_offset(attack_step)
	_spawn_hitbox_delayed(delay, offset, current_weapon.hitbox_scene)

func _start_heavy_attack() -> void:
	is_attacking = true
	is_heavy_attacking = true
	attack_step = 0

	var heavy_anim := current_weapon.heavy_anim
	sprite.play(String(heavy_anim))

	attack_lunge_speed = current_weapon.heavy_lunge_speed
	attack_lunge_timer = current_weapon.heavy_lunge_duration

	var scene := current_weapon.heavy_hitbox_scene if current_weapon.heavy_hitbox_scene != null else current_weapon.hitbox_scene
	_spawn_hitbox_delayed(current_weapon.heavy_hitbox_delay, current_weapon.heavy_hitbox_offset, scene)

	# Optional: slow down follow-up attacks after heavy
	attack_timer = attack_interval * heavy_attack_interval_multiplier


func _spawn_hitbox_delayed(delay: float, offset: Vector2, scene: PackedScene) -> void:
	if scene == null:
		return

	if delay > 0.0:
		await get_tree().create_timer(delay).timeout

	if not is_inside_tree() or stunned or !is_attacking or is_blocking:
		return
	if current_weapon == null:
		return

	var hitbox: Area2D = scene.instantiate()
	if hitbox == null:
		return

	add_child(hitbox)

	# If your hitbox supports it, set spawner
	if "spawner" in hitbox:
		hitbox.spawner = self

	# Position (flip X when facing left)
	var final_offset := offset
	if not facing_right:
		final_offset.x *= -1
	hitbox.global_position = hitbox_origin.global_position + final_offset

	# -------------------------
	# PUSH DAMAGE INTO HITBOX (FIX)
	# -------------------------
	var hb: Hitbox = null
	if hitbox is Hitbox:
		hb = hitbox as Hitbox

	if hb != null:
		hb.spawner = self

		# Determine which "step" this hitbox represents
		# - Heavy attacks use attack_step == 0 in your script
		# - Light attacks use 1..max
		var step_for_stats := (1 if attack_step <= 0 else attack_step)

		# Compute FIRST
		var shape: Shape2D = null
		var dmg: int = 0
		var stance_dmg: int = 0
		var kb: Vector2 = Vector2.ZERO
		var life: float = 0.12

		if is_heavy_attacking:
			shape = current_weapon.heavy_hitbox_shape
			dmg = int(current_weapon.heavy_damage)
			stance_dmg = int(current_weapon.heavy_stance_damage)
			kb = current_weapon.heavy_knockback
			life = float(current_weapon.heavy_hitbox_lifetime)
		else:
			shape = current_weapon.get_hitbox_shape(step_for_stats)
			dmg = current_weapon.get_damage(step_for_stats)
			stance_dmg = current_weapon.get_stance_damage(step_for_stats)
			kb = current_weapon.get_knockback(step_for_stats)
			life = current_weapon.get_hitbox_lifetime(step_for_stats)

		# Flip knockback X when facing left (same idea as player)
		kb *= Vector2(1 if facing_right else -1, 1)

		# Configure LAST
		hb.configure(
			null,      # vfx (optional)
			null,      # sfx (optional)
			Vector2.ZERO,
			shape,
			dmg,
			stance_dmg,
			kb,
			life
		)


func _on_animation_finished() -> void:
	if !is_attacking:
		return

	# Heavy ends immediately
	if is_heavy_attacking and sprite.animation == String(current_weapon.heavy_anim):
		_end_attack()
		return

	# Light chain: only continue if current animation matches our current step anim
	if !is_heavy_attacking:
		var expected := String(current_weapon.get_attack_anim(attack_step))
		if expected != "" and sprite.animation == expected:
			var max_hits := current_weapon.get_max_combo_hits()

			# Decide to chain
			if !stunned and randf() < combo_chance and attack_step < max_hits:
				_start_light_attack(attack_step + 1)
				return

	_end_attack()

func _end_attack() -> void:
	is_attacking = false
	is_heavy_attacking = false
	attack_step = 0
	attack_lunge_timer = 0.0

	if !is_blocking and !stunned:
		sprite.play("idle")


# -------------------------
# Damage
# -------------------------
func apply_knockback(kb: Vector2, _attacker_pos: Vector2) -> void:
	velocity = kb

func take_damage(amount: int, attacker_position: Vector2 = Vector2.ZERO):
	if !stunned:
		var blocked := is_blocking or (randf() < block_chance)
		if blocked:
			if block_on_success and !is_blocking:
				start_block(min(block_duration, 0.35))
			print("Blocked!")
			return

	health -= amount
	_update_health_bar()
	print("[ENEMY HIT] Damage received: ", amount, " | Health remaining: ", health, " / ", max_health, " | Attacker pos: ", attacker_position)

	stunned = true
	stun_timer = stun_duration

	if attacker_position != Vector2.ZERO:
		var knock_dir = sign(global_position.x - attacker_position.x)
		velocity.x = knock_dir * knockback_force.x
		velocity.y = knockback_force.y

	if health <= 0:
		die()

	if stance <= 0:
		die()

func die():
	print("Enemy died")
	queue_free()
