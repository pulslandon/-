extends CanvasLayer

var _overlay: ColorRect
var _label: Label

func _ready() -> void:
	layer = 128
	process_mode = Node.PROCESS_MODE_ALWAYS

	_overlay = ColorRect.new()
	_overlay.color = Color(0.0, 0.0, 0.0, 0.55)
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_overlay)

	_label = Label.new()
	_label.text = "PAUSED\nPress Escape to resume"
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_label)

	_set_visible(false)


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.is_action_pressed("Pause") and not event.is_echo():
		get_viewport().set_input_as_handled()
		_toggle()


func _toggle() -> void:
	get_tree().paused = not get_tree().paused
	_set_visible(get_tree().paused)


func _set_visible(show: bool) -> void:
	_overlay.visible = show
	_label.visible = show
