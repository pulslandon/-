class_name EquipmentData
extends Resource

enum Slot {CORE,}

@export var item_name: String = ""
@export var slot: Slot = Slot.CORE
@export var icon: Texture2D = null

# ── Stat modifiers ──────────────────────────────────────────────────────────
## Flat bonus added to max health on equip.
@export var health_bonus: int = 0

## Multiplier applied to move_speed (1.0 = no change, 1.1 = +10% speed).
@export var speed_multiplier: float = 1.0

## Flat bonus added to jump_force.
@export var jump_force_bonus: float = 0.0

## Flat bonus added to dash_speed.
@export var dash_speed_bonus: float = 0.0

## Seconds subtracted from dash_cooldown (clamped to 0).
@export var dash_cooldown_reduction: float = 0.0

## Multiplier applied to incoming damage (0.9 = 10% damage reduction).
## Stack multiple pieces multiplicatively.
@export var defense_multiplier: float = 1.0

## Subtracted from block_damage_multiplier (makes blocking cheaper).
@export var block_damage_multiplier_bonus: float = 0.0

## Multiplier applied to all outgoing damage (1.1 = +10% damage).
@export var damage_multiplier: float = 1.0
