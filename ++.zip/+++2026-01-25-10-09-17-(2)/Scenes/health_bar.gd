extends CanvasLayer

var _bar: ProgressBar
var _player: Node = null

func _ready() -> void:
	layer = 2
	process_mode = Node.PROCESS_MODE_ALWAYS

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_left", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	margin.add_child(vbox)

	var label := Label.new()
	label.text = "HP"
	vbox.add_child(label)

	_bar = ProgressBar.new()
	_bar.min_value = 0.0
	_bar.max_value = 100.0
	_bar.value = 100.0
	_bar.custom_minimum_size = Vector2(200.0, 20.0)
	_bar.show_percentage = false
	vbox.add_child(_bar)


func _process(_delta: float) -> void:
	if not is_instance_valid(_player):
		_player = get_tree().get_first_node_in_group("player")
	if _player == null:
		return
	_bar.max_value = float(_player.get("_base_health") if _player.get("_base_health") else 100)
	_bar.value = float(_player.get("health"))
