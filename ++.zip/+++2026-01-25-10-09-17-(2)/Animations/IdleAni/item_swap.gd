extends Area2D

## All equippable items available to the player. Add EquipmentData resources here.
@export var items: Array[EquipmentData] = []

var _player: Node = null
var _prompt: Label = null
var _canvas: CanvasLayer = null

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

	_prompt = Label.new()
	_prompt.text = "[E] Equip Item"
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.position = Vector2(-60.0, -80.0)
	_prompt.visible = false
	add_child(_prompt)


func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or event.is_echo():
		return
	if _canvas != null and (event.is_action_pressed("Interact") or event.is_action_pressed("Pause")):
		_close_menu()
	elif _player != null and _canvas == null and event.is_action_pressed("Interact"):
		_open_menu()


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		_player = body
		_prompt.visible = true


func _on_body_exited(body: Node) -> void:
	if body == _player:
		_player = null
		_prompt.visible = false
		_close_menu()


func _open_menu() -> void:
	_prompt.visible = false
	_canvas = CanvasLayer.new()
	_canvas.layer = 64
	get_tree().current_scene.add_child(_canvas)

	var bg := ColorRect.new()
	bg.color = Color(0.0, 0.0, 0.0, 0.65)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_canvas.add_child(bg)

	var vbox := VBoxContainer.new()
	vbox.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	vbox.add_theme_constant_override("separation", 12)
	_canvas.add_child(vbox)

	var title := Label.new()
	title.text = "Equip Item"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	for item: EquipmentData in items:
		if item == null:
			continue
		var btn := Button.new()
		btn.text = item.item_name
		btn.custom_minimum_size = Vector2(220.0, 48.0)
		btn.pressed.connect(func() -> void:
			_player.equip_item(item)
			_close_menu())
		vbox.add_child(btn)

	var close_btn := Button.new()
	close_btn.text = "Close  [E]"
	close_btn.custom_minimum_size = Vector2(220.0, 48.0)
	close_btn.pressed.connect(_close_menu)
	vbox.add_child(close_btn)


func _close_menu() -> void:
	if _canvas == null:
		return
	_canvas.queue_free()
	_canvas = null
	if _player != null:
		_prompt.visible = true
