extends Area2D

## Point this to the paired exit Teleporter (or any Node2D).
@export var destination: Node2D = null

var _cooldown: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if _cooldown or destination == null:
		return
	if not body.is_in_group("player"):
		return

	body.global_position = destination.global_position
	if body.has_method("get") and body.get("velocity") != null:
		body.velocity = Vector2.ZERO

	_start_cooldown()
	# Cool down the destination too so the player doesn't instantly teleport back.
	if destination.has_method("_start_cooldown"):
		destination._start_cooldown()

func _start_cooldown() -> void:
	_cooldown = true
	await get_tree().create_timer(0.8).timeout
	_cooldown = false
