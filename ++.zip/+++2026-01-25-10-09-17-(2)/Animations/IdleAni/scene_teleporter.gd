extends Area2D

@export_file("*.tscn") var target_scene: String = ""

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if target_scene == "" or not body.is_in_group("player"):
		return
	get_tree().change_scene_to_file(target_scene)
